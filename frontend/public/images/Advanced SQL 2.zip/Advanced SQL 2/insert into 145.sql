INSERT INTO `classicmodels`.`customer_service_ticket`
(`customer_service_ticket_raise_time`, `customerNumber`)
VALUES (CURRENT_TIMESTAMP, 145);