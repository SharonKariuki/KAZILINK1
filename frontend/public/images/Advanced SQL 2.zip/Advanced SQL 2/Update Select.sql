UPDATE `classicmodels`.`customer_service_ticket` SET
`customer_service_ticket_resolved` = '1' WHERE
(`customer_service_ticket_ID` = '2');
