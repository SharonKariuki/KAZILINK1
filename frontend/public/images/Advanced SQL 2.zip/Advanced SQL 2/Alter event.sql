ALTER EVENT EVN_record_customer_waiting_time_every_1_minute_for_1_hour
RENAME TO EVN_record_customer_waiting_time_every_2_minutes_for_1_hour;
ALTER EVENT EVN_record_customer_waiting_time_every_2_minutes_for_1_hour
ON SCHEDULE EVERY 2 MINUTE
DO
UPDATE `classicmodels`.`customer_service_ticket`
SET
 `customer_service_total_wait_time_minutes` = TIMESTAMPDIFF(MINUTE,
 `customer_service_ticket_raise_time`,
 CURRENT_TIMESTAMP),
 `customer_service_ticket_last_update` = CONCAT('The last 2-minute
recurring update was made at ', CURRENT_TIMESTAMP)
WHERE
 `customer_service_ticket_resolved` = 0;