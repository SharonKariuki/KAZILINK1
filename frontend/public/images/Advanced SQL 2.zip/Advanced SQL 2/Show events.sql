SHOW EVENTS FROM classicmodels;
