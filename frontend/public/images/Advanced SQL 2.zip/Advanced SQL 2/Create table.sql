CREATE TABLE `classicmodels`.`customer_service_ticket` (
 `customer_service_ticket_ID` int unsigned NOT NULL AUTO_INCREMENT COMMENT
'Identifies the ticket number',
 `customer_service_ticket_resolved` tinyint NOT NULL DEFAULT '0' COMMENT
'Indicates whether the issue raised via the ticket has been resolved (1 if
resolved and 0 if not resolved)',
 `customer_service_ticket_raise_time` timestamp NOT NULL COMMENT 'Records
the time when the ticket was raised by the client. Required to know when to
start the timer.',
 `customer_service_total_wait_time_minutes` int DEFAULT NULL COMMENT
'Records the total amount of time elapsed since the customer raised the
ticket.',
 `customer_service_ticket_last_update` text DEFAULT NULL COMMENT 'Records
a message that specifies when the last update was made by firing the
event',
 `customerNumber` int DEFAULT NULL COMMENT 'Identifies the customer who
has raised the ticket',
 PRIMARY KEY (`customer_service_ticket_ID`),
 CONSTRAINT `FK_1_customers_TO_M_customer_service_ticket` FOREIGN KEY
(`customerNumber`) REFERENCES `customers` (`customerNumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci
COMMENT='Used to keep track of how long an issue raised via a IT ticketing
system has remained unresolved.';
