/*6--CS instructors*/
CREATE VIEW CSinstructors AS SELECT * FROM instructor WHERE dept_name = 'Comp. Sci.';