/*Advanced SQL*/
/*1 - unoverriden Fs*/
CREATE VIEW unoverridden_fails AS
SELECT *
FROM takes t1
WHERE t1.grade = 'F'
  AND NOT EXISTS (
    SELECT 1
    FROM takes t2
    WHERE t2.ID = t1.ID
      AND t2.course_id = t1.course_id
      AND t2.grade IS NOT NULL
      AND t2.grade <> 'F'
  );