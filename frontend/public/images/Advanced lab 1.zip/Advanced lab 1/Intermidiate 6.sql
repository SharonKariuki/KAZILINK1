/*6a insert instructors as students*/
INSERT INTO student (ID, name, dept_name, tot_cred)
SELECT i.ID, i.name, i.dept_name, 0
FROM instructor i
WHERE i.ID NOT IN (SELECT ID FROM student);
