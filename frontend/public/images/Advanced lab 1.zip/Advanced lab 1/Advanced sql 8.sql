/*8- Grant access to friend to see data*/
GRANT SELECT ON university1.student TO 'johndoe'@'localhost';