/*4*/
SELECT * FROM course where course_id LIKE 'CS-1%';
