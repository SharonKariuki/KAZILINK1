/*9*/
UPDATE instructor i
SET salary = (
    SELECT COUNT(*) * 10000
    FROM teaches t
    WHERE t.ID = i.ID
);