/*5-- create a view faculty*/
CREATE VIEW faculty AS SELECT ID, name, dept_name FROM instructor;