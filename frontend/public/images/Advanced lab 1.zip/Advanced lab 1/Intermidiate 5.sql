/*5a 'not exists' structure*/
SELECT i.ID, i.name
FROM instructor i
WHERE NOT EXISTS (
    SELECT course_id
    FROM course
    WHERE course_id LIKE 'CS-1%'
    
    EXCEPT

    SELECT t.course_id
    FROM teaches t
    WHERE t.ID = i.ID
      AND t.course_id LIKE 'CS-1%'
);

/*5b matching counts*/
SELECT i.ID, i.name
FROM instructor i
JOIN teaches t ON i.ID = t.ID
WHERE t.course_id LIKE 'CS-1%'
GROUP BY i.ID, i.name
HAVING COUNT(DISTINCT t.course_id) = (
    SELECT COUNT(DISTINCT course_id)
    FROM course
    WHERE course_id LIKE 'CS-1%'
);