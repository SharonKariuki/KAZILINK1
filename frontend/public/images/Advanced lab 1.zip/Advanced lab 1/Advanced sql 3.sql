/*3*/

CREATE TABLE grade_points (
    grade VARCHAR(2) PRIMARY KEY,
    points INT
);

INSERT INTO grade_points (grade, points) VALUES
('A', 10),
('A-', 9),
('B+', 8),
('B', 8),
('B-', 7),
('C+', 6),
('C', 6),
('C-', 5),
('D+', 4),
('D', 4),
('D-', 3),
('F', 0);

SELECT 
    s.ID,
    s.name,
    ROUND(SUM(c.credits * gp.points) / SUM(c.credits), 2) AS CPI
FROM student s
LEFT JOIN takes t ON s.ID = t.ID AND t.grade IS NOT NULL
LEFT JOIN course c ON t.course_id = c.course_id
LEFT JOIN grade_points gp ON t.grade = gp.grade
GROUP BY s.ID, s.name;
