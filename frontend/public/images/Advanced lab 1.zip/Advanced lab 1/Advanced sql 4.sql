/*4 -rooms*/
WITH section_info AS (
    SELECT 
        course_id,
        sec_id,
        semester,
        year,
        building,
        room_number,
        time_slot_id
    FROM section
),
conflicts AS (
    SELECT 
        s1.building,
        s1.room_number,
        s1.semester,
        s1.year,
        s1.time_slot_id,
        s1.course_id AS course1,
        s1.sec_id AS sec1,
        s2.course_id AS course2,
        s2.sec_id AS sec2
    FROM section_info s1
    JOIN section_info s2
      ON s1.building = s2.building
     AND s1.room_number = s2.room_number
     AND s1.semester = s2.semester
     AND s1.year = s2.year
     AND s1.time_slot_id = s2.time_slot_id
     AND (s1.course_id, s1.sec_id) < (s2.course_id, s2.sec_id)  -- avoid duplicates/self-match
)
SELECT *
FROM conflicts;