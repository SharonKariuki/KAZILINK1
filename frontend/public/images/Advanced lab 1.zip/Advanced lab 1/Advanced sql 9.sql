/*9- grant access to all users*/
SELECT user, host FROM mysql.user WHERE user = 'johndoe' AND host = 'localhost';
CREATE USER 'johndoe'@'localhost' IDENTIFIED BY '12345';
GRANT SELECT ON university1.student TO 'johndoe'@'localhost';
SELECT user, host FROM mysql.user WHERE user = 'paulturner' AND host = 'localhost';
CREATE USER 'paulturner'@'localhost' IDENTIFIED BY '1234';
GRANT SELECT ON university1.student TO 'paulturner'@'localhost';