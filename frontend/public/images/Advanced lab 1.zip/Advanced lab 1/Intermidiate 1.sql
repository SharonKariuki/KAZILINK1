/*1*/

SELECT 
    MAX(enrollment_count) AS max_enrollment,
    MIN(enrollment_count) AS min_enrollment
FROM (
    SELECT 
        course_id, sec_id, semester, year, 
        COUNT(*) AS enrollment_count
    FROM takes
    GROUP BY course_id, sec_id, semester, year
) AS section_enrollments;
