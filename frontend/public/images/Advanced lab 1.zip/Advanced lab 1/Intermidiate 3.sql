/*3-- scalar subquery*/
SELECT 
    MAX(enrollment) AS max_enrollment,
    MIN(enrollment) AS min_enrollment
FROM (
    SELECT 
        s.course_id,
        s.sec_id,
        s.semester,
        s.year,
        (
            SELECT COUNT(*) 
            FROM takes t 
            WHERE t.course_id = s.course_id 
              AND t.sec_id = s.sec_id 
              AND t.semester = s.semester 
              AND t.year = s.year
        ) AS enrollment
    FROM section s
) AS section_with_enrollment;

/*3b aggregation on a left outer join*/
SELECT 
    MAX(enrollment) AS max_enrollment,
    MIN(enrollment) AS min_enrollment
FROM (
    SELECT 
        s.course_id,
        s.sec_id,
        s.semester,
        s.year,
        IFNULL(t.enrollment, 0) AS enrollment
    FROM section s
    LEFT JOIN (
        SELECT 
            course_id, sec_id, semester, year, COUNT(*) AS enrollment
        FROM takes
        GROUP BY course_id, sec_id, semester, year
    ) t ON s.course_id = t.course_id 
        AND s.sec_id = t.sec_id 
        AND s.semester = t.semester 
        AND s.year = t.year
) AS result;