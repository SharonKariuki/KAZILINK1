/*7 delete*/
DELETE FROM student
WHERE tot_cred = 0
  AND ID IN (SELECT ID FROM instructor);