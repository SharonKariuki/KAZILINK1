 /*8 Update student*/
UPDATE student s
SET tot_cred = (
    SELECT IFNULL(SUM(c.credits), 0)
    FROM takes t
    JOIN course c ON t.course_id = c.course_id
    WHERE t.ID = s.ID AND t.grade IS NOT NULL
);