/*7 -appropriate tuple into faculty and CS instructors*/
INSERT INTO faculty (ID, name, dept_name)
VALUES ('99991', 'Alan Turing', 'Comp. Sci.');

SELECT * FROM instructor WHERE ID = '99991';

INSERT INTO CSinstructors (ID, name, dept_name, salary)
 VALUES ('99992', 'Ada Lovelace', 'Comp. Sci.', 95000);

INSERT INTO CSinstructors (ID, name, dept_name, salary)
VALUES ('99993', 'Katherine Johnson', 'Physics', 85000);
