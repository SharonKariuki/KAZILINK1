/*2- find students with 2 or more non-overriden Fs - no result returned */
SELECT t.*
FROM takes t
WHERE t.grade = 'F'
  AND NOT EXISTS (
    SELECT 1
    FROM takes t2
    WHERE t2.ID = t.ID
      AND t2.course_id = t.course_id
      AND t2.grade IS NOT NULL
      AND t2.grade <> 'F'
  )
  AND t.ID IN (
    SELECT t1.ID
    FROM takes t1
    WHERE t1.grade = 'F'
      AND NOT EXISTS (
        SELECT 1
        FROM takes t2
        WHERE t2.ID = t1.ID
          AND t2.course_id = t1.course_id
          AND t2.grade IS NOT NULL
          AND t2.grade <> 'F'
      )
    GROUP BY t1.ID
    HAVING COUNT(*) >= 2
  );